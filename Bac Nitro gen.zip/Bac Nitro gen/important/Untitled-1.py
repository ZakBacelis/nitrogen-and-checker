try: 
    from discord_webhook import DiscordWebhook
except ImportError: 
    input(f"Module discord_webhook not installed, to install run '{'py -3' if os.name == 'nt' else 'python3.8'} -m pip install discord_webhook'\nPress enter to exit") 
    exit()  

    notify = input("webhook: ")  



DiscordWebhook( 
              url = notify,
           content = f"Test"
         ).execute()